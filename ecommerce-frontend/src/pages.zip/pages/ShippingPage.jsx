import { useState, useContext } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { CartContext } from '../context/CartContext';

const ShippingPage = () => {
  const { shippingAddress, saveShippingAddress, cartItems } = useContext(CartContext);
  const navigate = useNavigate();

  // Contact Information State 
  const [firstName, setFirstName] = useState(shippingAddress.firstName || '');
  const [lastName, setLastName] = useState(shippingAddress.lastName || '');
  const [email, setEmail] = useState(shippingAddress.email || '');
  const [confirmEmail, setConfirmEmail] = useState(shippingAddress.confirmEmail || '');
  const [phone, setPhone] = useState(shippingAddress.phone || '');
  
  // Shipping Address State
  const [shippingAddressLine, setShippingAddressLine] = useState(shippingAddress.shippingAddressLine || '');
  const [shippingApt, setShippingApt] = useState(shippingAddress.shippingApt || '');
  const [shippingCity, setShippingCity] = useState(shippingAddress.shippingCity || '');
  const [shippingState, setShippingState] = useState(shippingAddress.shippingState || '');
  const [shippingPostalCode, setShippingPostalCode] = useState(shippingAddress.shippingPostalCode || '');
  const [shippingCountry, setShippingCountry] = useState(shippingAddress.shippingCountry || '');
  
  // Billing Address State
  const [billingSameAsShipping, setBillingSameAsShipping] = useState(true);
  const [billingAddressLine, setBillingAddressLine] = useState(shippingAddress.billingAddressLine || '');
  const [billingApt, setBillingApt] = useState(shippingAddress.billingApt || '');
  const [billingCity, setBillingCity] = useState(shippingAddress.billingCity || '');
  const [billingState, setBillingState] = useState(shippingAddress.billingState || '');
  const [billingPostalCode, setBillingPostalCode] = useState(shippingAddress.billingPostalCode || '');
  const [billingCountry, setBillingCountry] = useState(shippingAddress.billingCountry || '');
  
  // Shipping Options State
  const [shippingCost, setShippingCost] = useState(shippingAddress.shippingCost || 5.00);
  const [shippingMethod, setShippingMethod] = useState(shippingAddress.shippingMethod || 'Standard');
  
  // Promo Code State
  const [promoCode, setPromoCode] = useState('');
  const [promoDiscount, setPromoDiscount] = useState(0);
  const [promoMessage, setPromoMessage] = useState('');
  const [promoApplied, setPromoApplied] = useState(false);
  
  // Form validation errors
  const [errors, setErrors] = useState({});

  // Valid promo codes
  const validPromoCodes = {
    'WELCOME10': { discount: 0.10, type: 'percentage', message: '10% discount applied!' },
    'SAVE20': { discount: 20, type: 'fixed', message: '€20 discount applied!' },
    'EUROSHIP': { discount: 5, type: 'fixed', message: '€5 shipping discount applied!' },
    'FREESHIP': { discount: 0, type: 'free_shipping', message: 'Free shipping applied!' }
  };

  const subtotal = cartItems.reduce((total, item) => total + (Number(item.price) * (item.qty || 1)), 0);
  
  let discountedSubtotal = subtotal;
  let finalShippingCost = shippingCost;
  
  if (promoApplied && validPromoCodes[promoCode]) {
    const promo = validPromoCodes[promoCode];
    if (promo.type === 'percentage') {
      discountedSubtotal = subtotal * (1 - promo.discount);
    } else if (promo.type === 'fixed') {
      discountedSubtotal = Math.max(0, subtotal - promo.discount);
    } else if (promo.type === 'free_shipping') {
      finalShippingCost = 0;
    }
  }
  
  const finalTotal = discountedSubtotal + finalShippingCost;

  const applyPromoCode = () => {
    const upperCode = promoCode.toUpperCase();
    if (validPromoCodes[upperCode]) {
      setPromoApplied(true);
      setPromoMessage(validPromoCodes[upperCode].message);
      if (validPromoCodes[upperCode].type === 'free_shipping') {
        setPromoDiscount(0);
      } else if (validPromoCodes[upperCode].type === 'percentage') {
        setPromoDiscount(subtotal * validPromoCodes[upperCode].discount);
      } else {
        setPromoDiscount(validPromoCodes[upperCode].discount);
      }
    } else {
      setPromoApplied(false);
      setPromoMessage('Invalid promo code');
      setPromoDiscount(0);
    }
  };

  const getEstimatedDelivery = (method) => {
    const today = new Date();
    let minDays, maxDays;
    switch(method) {
      case 'Expedited': minDays = 1; maxDays = 2; break;
      case 'Economy': minDays = 5; maxDays = 8; break;
      default: minDays = 3; maxDays = 5;
    }
    const startDate = new Date(today);
    startDate.setDate(today.getDate() + minDays);
    const endDate = new Date(today);
    endDate.setDate(today.getDate() + maxDays);
    return {
      start: startDate.toLocaleDateString('en-GB', { day: 'numeric', month: 'short' }),
      end: endDate.toLocaleDateString('en-GB', { day: 'numeric', month: 'short' })
    };
  };

  const handleBillingSameToggle = (checked) => {
    setBillingSameAsShipping(checked);
    if (checked) {
      setBillingAddressLine(shippingAddressLine);
      setBillingApt(shippingApt);
      setBillingCity(shippingCity);
      setBillingState(shippingState);
      setBillingPostalCode(shippingPostalCode);
      setBillingCountry(shippingCountry);
    }
  };

  const validateForm = () => {
    const newErrors = {};
    if (!firstName.trim()) newErrors.firstName = 'Required';
    if (!lastName.trim()) newErrors.lastName = 'Required';
    if (!email.trim() || !/\S+@\S+\.\S+/.test(email)) newErrors.email = 'Valid email required';
    if (email !== confirmEmail) newErrors.confirmEmail = 'Emails do not match';
    if (!phone.trim()) newErrors.phone = 'Required';
    
    if (!shippingAddressLine.trim()) newErrors.shippingAddressLine = 'Required';
    if (!shippingCity.trim()) newErrors.shippingCity = 'Required';
    if (!shippingState.trim()) newErrors.shippingState = 'Required';
    if (!shippingPostalCode.trim()) newErrors.shippingPostalCode = 'Required';
    if (!shippingCountry.trim()) newErrors.shippingCountry = 'Required';
    
    if (!billingSameAsShipping) {
      if (!billingAddressLine.trim()) newErrors.billingAddressLine = 'Required';
      if (!billingCity.trim()) newErrors.billingCity = 'Required';
      if (!billingState.trim()) newErrors.billingState = 'Required';
      if (!billingPostalCode.trim()) newErrors.billingPostalCode = 'Required';
      if (!billingCountry.trim()) newErrors.billingCountry = 'Required';
    }
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const submitHandler = (e) => {
    e.preventDefault();
    if (validateForm()) {
      saveShippingAddress({
        firstName, lastName, email, phone,
        shippingAddressLine, shippingApt, shippingCity, shippingState, shippingPostalCode, shippingCountry,
        billingSameAsShipping,
        billingAddressLine: billingSameAsShipping ? shippingAddressLine : billingAddressLine,
        billingCity: billingSameAsShipping ? shippingCity : billingCity,
        billingState: billingSameAsShipping ? shippingState : billingState,
        billingPostalCode: billingSameAsShipping ? shippingPostalCode : billingPostalCode,
        billingCountry: billingSameAsShipping ? shippingCountry : billingCountry,
        shippingMethod, shippingCost: finalShippingCost,
        promoCode: promoApplied ? promoCode : null,
        promoDiscount, finalTotal
      });
      navigate('/payment');
    } else {
      window.scrollTo(0,0); // Scroll to top to see errors
    }
  };

  const europeanCountries = ['United Kingdom', 'Germany', 'France', 'Italy', 'Spain', 'Netherlands', 'Ireland', 'Sweden'];

  const getStatesForCountry = () => {
    if (shippingCountry === 'Germany') return ['Berlin', 'Bavaria', 'Hamburg'];
    if (shippingCountry === 'United Kingdom') return ['England', 'Scotland', 'Wales', 'Northern Ireland'];
    return ['State/Province'];
  };

  const states = getStatesForCountry();

  return (
    <div className="max-w-7xl mx-auto p-4 md:p-8 mt-6">
      
      {/* PROGRESS INDICATOR */}
      <div className="flex justify-center items-center mb-10">
        <div className="flex items-center space-x-2 md:space-x-6">
          <div className="flex flex-col items-center">
            <div className="w-8 h-8 rounded-full bg-blue-600 text-white flex items-center justify-center text-sm font-bold">1</div>
            <span className="text-xs mt-1 text-blue-600 font-semibold">Cart</span>
          </div>
          <div className="w-12 md:w-16 h-0.5 bg-blue-600"></div>
          <div className="flex flex-col items-center">
            <div className="w-8 h-8 rounded-full bg-blue-600 text-white flex items-center justify-center text-sm font-bold">2</div>
            <span className="text-xs mt-1 text-gray-900 font-semibold border-b-2 border-gray-900 pb-1">Checkout</span>
          </div>
          <div className="w-12 md:w-16 h-0.5 bg-gray-300"></div>
          <div className="flex flex-col items-center">
            <div className="w-8 h-8 rounded-full bg-gray-300 text-gray-600 flex items-center justify-center text-sm font-bold">3</div>
            <span className="text-xs mt-1 text-gray-500">Payment</span>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 lg:gap-10">
        
        {/* LEFT COLUMN: FORM */}
        <div className="lg:col-span-2">
          <div className="flex items-center justify-between mb-6">
            <h1 className="text-2xl md:text-3xl font-extrabold text-gray-900">Checkout</h1>
            <div className="bg-green-50 text-green-700 text-sm font-semibold px-4 py-2 rounded-full flex items-center gap-2">
              <i className="fas fa-check-circle"></i> Guest checkout available
            </div>
          </div>
          
          <form onSubmit={submitHandler} className="space-y-8">
            
            {/* CONTACT INFO */}
            <div className="bg-white rounded-xl border border-gray-200 p-6 shadow-sm">
              <h2 className="text-lg font-extrabold text-gray-900 mb-4 flex items-center gap-2">
                <i className="fas fa-user text-blue-600"></i> Contact Information
              </h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-gray-700 font-semibold mb-2">First Name *</label>
                  <input type="text" value={firstName} onChange={(e) => setFirstName(e.target.value)} className={`w-full p-3 border rounded-xl focus:ring-2 focus:ring-blue-600 outline-none ${errors.firstName ? 'border-red-500 bg-red-50' : 'border-gray-300'}`} />
                  {errors.firstName && <p className="text-red-500 text-xs mt-1">{errors.firstName}</p>}
                </div>
                <div>
                  <label className="block text-gray-700 font-semibold mb-2">Last Name *</label>
                  <input type="text" value={lastName} onChange={(e) => setLastName(e.target.value)} className={`w-full p-3 border rounded-xl focus:ring-2 focus:ring-blue-600 outline-none ${errors.lastName ? 'border-red-500 bg-red-50' : 'border-gray-300'}`} />
                  {errors.lastName && <p className="text-red-500 text-xs mt-1">{errors.lastName}</p>}
                </div>
                <div>
                  <label className="block text-gray-700 font-semibold mb-2">Email *</label>
                  <input type="email" value={email} onChange={(e) => setEmail(e.target.value)} className={`w-full p-3 border rounded-xl focus:ring-2 focus:ring-blue-600 outline-none ${errors.email ? 'border-red-500 bg-red-50' : 'border-gray-300'}`} />
                  {errors.email && <p className="text-red-500 text-xs mt-1">{errors.email}</p>}
                </div>
                <div>
                  <label className="block text-gray-700 font-semibold mb-2">Confirm Email *</label>
                  <input type="email" value={confirmEmail} onChange={(e) => setConfirmEmail(e.target.value)} className={`w-full p-3 border rounded-xl focus:ring-2 focus:ring-blue-600 outline-none ${errors.confirmEmail ? 'border-red-500 bg-red-50' : 'border-gray-300'}`} />
                  {errors.confirmEmail && <p className="text-red-500 text-xs mt-1">{errors.confirmEmail}</p>}
                </div>
                <div className="md:col-span-2">
                  <label className="block text-gray-700 font-semibold mb-2">Phone *</label>
                  <input type="tel" value={phone} onChange={(e) => setPhone(e.target.value)} className={`w-full p-3 border rounded-xl focus:ring-2 focus:ring-blue-600 outline-none ${errors.phone ? 'border-red-500 bg-red-50' : 'border-gray-300'}`} />
                  {errors.phone && <p className="text-red-500 text-xs mt-1">{errors.phone}</p>}
                </div>
              </div>
            </div>

            {/* SHIPPING ADDRESS */}
            <div className="bg-white rounded-xl border border-gray-200 p-6 shadow-sm">
              <h2 className="text-lg font-extrabold text-gray-900 mb-4 flex items-center gap-2">
                <i className="fas fa-truck text-blue-600"></i> Shipping Address
              </h2>
              <div className="space-y-4">
                <div>
                  <label className="block text-gray-700 font-semibold mb-2">Street Address *</label>
                  <input type="text" value={shippingAddressLine} onChange={(e) => setShippingAddressLine(e.target.value)} className={`w-full p-3 border rounded-xl focus:ring-2 focus:ring-blue-600 outline-none ${errors.shippingAddressLine ? 'border-red-500 bg-red-50' : 'border-gray-300'}`} />
                  {errors.shippingAddressLine && <p className="text-red-500 text-xs mt-1">{errors.shippingAddressLine}</p>}
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-gray-700 font-semibold mb-2">City *</label>
                    <input type="text" value={shippingCity} onChange={(e) => setShippingCity(e.target.value)} className={`w-full p-3 border rounded-xl focus:ring-2 focus:ring-blue-600 outline-none ${errors.shippingCity ? 'border-red-500 bg-red-50' : 'border-gray-300'}`} />
                    {errors.shippingCity && <p className="text-red-500 text-xs mt-1">{errors.shippingCity}</p>}
                  </div>
                  <div>
                    <label className="block text-gray-700 font-semibold mb-2">State/Province *</label>
                    <input type="text" value={shippingState} onChange={(e) => setShippingState(e.target.value)} className={`w-full p-3 border rounded-xl focus:ring-2 focus:ring-blue-600 outline-none ${errors.shippingState ? 'border-red-500 bg-red-50' : 'border-gray-300'}`} />
                  </div>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-gray-700 font-semibold mb-2">Postal Code *</label>
                    <input type="text" value={shippingPostalCode} onChange={(e) => setShippingPostalCode(e.target.value)} className={`w-full p-3 border rounded-xl focus:ring-2 focus:ring-blue-600 outline-none ${errors.shippingPostalCode ? 'border-red-500 bg-red-50' : 'border-gray-300'}`} />
                    {errors.shippingPostalCode && <p className="text-red-500 text-xs mt-1">{errors.shippingPostalCode}</p>}
                  </div>
                  <div>
                    <label className="block text-gray-700 font-semibold mb-2">Country *</label>
                    <select value={shippingCountry} onChange={(e) => setShippingCountry(e.target.value)} className={`w-full p-3 border rounded-xl focus:ring-2 focus:ring-blue-600 outline-none ${errors.shippingCountry ? 'border-red-500 bg-red-50' : 'border-gray-300'}`}>
                      <option value="">Select Country</option>
                      {europeanCountries.map(c => <option key={c} value={c}>{c}</option>)}
                    </select>
                  </div>
                </div>
              </div>
            </div>

            {/* BILLING TOGGLE */}
            <div className="bg-white rounded-xl border border-gray-200 p-6 shadow-sm">
  <div className="flex items-center justify-between mb-4">
    <h2 className="text-lg font-extrabold text-gray-900 flex items-center gap-2">
      <i className="fas fa-file-invoice text-blue-600"></i> Billing Address
    </h2>
    <label className="flex items-center gap-2 cursor-pointer">
      <input 
        type="checkbox" 
        checked={billingSameAsShipping} 
        onChange={(e) => handleBillingSameToggle(e.target.checked)} 
        className="w-5 h-5 text-blue-600 rounded focus:ring-blue-500" 
      />
      <span className="text-sm text-gray-700 font-medium">Same as shipping</span>
    </label>
  </div>
  
  {!billingSameAsShipping && (
    <div className="mt-4 space-y-4">
      <div>
        <label className="block text-gray-700 font-semibold mb-2">Street Address *</label>
        <input 
          type="text" 
          value={billingAddressLine} 
          onChange={(e) => setBillingAddressLine(e.target.value)} 
          className={`w-full p-3 border rounded-xl focus:ring-2 focus:ring-blue-600 outline-none ${errors.billingAddressLine ? 'border-red-500 bg-red-50' : 'border-gray-300'}`} 
        />
        {errors.billingAddressLine && <p className="text-red-500 text-xs mt-1">{errors.billingAddressLine}</p>}
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
          <label className="block text-gray-700 font-semibold mb-2">City *</label>
          <input 
            type="text" 
            value={billingCity} 
            onChange={(e) => setBillingCity(e.target.value)} 
            className={`w-full p-3 border rounded-xl focus:ring-2 focus:ring-blue-600 outline-none ${errors.billingCity ? 'border-red-500 bg-red-50' : 'border-gray-300'}`} 
          />
          {errors.billingCity && <p className="text-red-500 text-xs mt-1">{errors.billingCity}</p>}
        </div>
        <div>
          <label className="block text-gray-700 font-semibold mb-2">State/Province *</label>
          <input 
            type="text" 
            value={billingState} 
            onChange={(e) => setBillingState(e.target.value)} 
            className={`w-full p-3 border rounded-xl focus:ring-2 focus:ring-blue-600 outline-none ${errors.billingState ? 'border-red-500 bg-red-50' : 'border-gray-300'}`} 
          />
          {errors.billingState && <p className="text-red-500 text-xs mt-1">{errors.billingState}</p>}
        </div>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
          <label className="block text-gray-700 font-semibold mb-2">Postal Code *</label>
          <input 
            type="text" 
            value={billingPostalCode} 
            onChange={(e) => setBillingPostalCode(e.target.value)} 
            className={`w-full p-3 border rounded-xl focus:ring-2 focus:ring-blue-600 outline-none ${errors.billingPostalCode ? 'border-red-500 bg-red-50' : 'border-gray-300'}`} 
          />
          {errors.billingPostalCode && <p className="text-red-500 text-xs mt-1">{errors.billingPostalCode}</p>}
        </div>
        <div>
          <label className="block text-gray-700 font-semibold mb-2">Country *</label>
          <select 
            value={billingCountry} 
            onChange={(e) => setBillingCountry(e.target.value)} 
            className={`w-full p-3 border rounded-xl focus:ring-2 focus:ring-blue-600 outline-none ${errors.billingCountry ? 'border-red-500 bg-red-50' : 'border-gray-300'}`}
          >
            <option value="">Select Country</option>
            {europeanCountries.map(c => <option key={c} value={c}>{c}</option>)}
          </select>
          {errors.billingCountry && <p className="text-red-500 text-xs mt-1">{errors.billingCountry}</p>}
        </div>
      </div>
    </div>
  )}
</div>
            {/* SHIPPING OPTIONS */}
            <div className="bg-white rounded-xl border border-gray-200 p-6 shadow-sm">
              <h2 className="text-lg font-extrabold text-gray-900 mb-4 flex items-center gap-2">
                <i className="fas fa-box text-blue-600"></i> Delivery Method
              </h2>
              <div className="space-y-3">
                {['Standard', 'Expedited', 'Economy'].map(method => (
                  <label key={method} className={`flex items-center justify-between p-4 border rounded-xl cursor-pointer transition-all ${shippingMethod === method ? 'border-blue-600 bg-blue-50 shadow-sm' : 'border-gray-200'}`}>
                    <div className="flex items-center gap-3">
                      <input type="radio" checked={shippingMethod === method} onChange={() => { setShippingMethod(method); setShippingCost(method === 'Standard' ? 5 : method === 'Expedited' ? 15 : 0); }} className="w-5 h-5 text-blue-600" />
                      <div>
                        <span className="block font-bold text-gray-900">{method} Shipping</span>
                        <span className="block text-sm text-gray-500">Arrives {getEstimatedDelivery(method).start} - {getEstimatedDelivery(method).end}</span>
                      </div>
                    </div>
                    <span className={`font-bold ${method === 'Economy' ? 'text-green-600' : 'text-gray-900'}`}>{method === 'Economy' ? 'FREE' : method === 'Standard' ? '€5.00' : '€15.00'}</span>
                  </label>
                ))}
              </div>
            </div>

            {/* PROMO CODE */}
            <div className="bg-white rounded-xl border border-gray-200 p-6 shadow-sm">
              <h2 className="text-lg font-extrabold text-gray-900 mb-4 flex items-center gap-2">
                <i className="fas fa-tag text-blue-600"></i> Promo Code
              </h2>
              <div className="flex gap-3">
                <input type="text" value={promoCode} onChange={(e) => setPromoCode(e.target.value)} className="flex-1 p-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-600 outline-none" placeholder="WELCOME10, SAVE20, FREESHIP" />
                <button type="button" onClick={applyPromoCode} className="px-6 py-3 bg-gray-800 text-white rounded-xl font-semibold hover:bg-gray-900 transition">Apply</button>
              </div>
              {promoMessage && <p className={`text-sm mt-2 ${promoApplied ? 'text-green-600' : 'text-red-500'}`}>{promoMessage}</p>}
            </div>

            <button type="submit" className="w-full bg-blue-600 text-white py-4 rounded-xl font-extrabold text-lg hover:bg-blue-700 transition-all shadow-md flex items-center justify-center gap-2">
              Continue to Payment <i className="fas fa-arrow-right"></i>
            </button>
          </form>
        </div>

        {/* RIGHT COLUMN: ORDER SUMMARY */}
        <div className="lg:col-span-1">
          <div className="bg-gray-50 rounded-xl border border-gray-200 sticky top-24 p-6">
            <h2 className="text-xl font-extrabold text-gray-900 mb-4 flex items-center gap-2">
              <i className="fas fa-shopping-bag"></i> Order Summary
            </h2>
            
            <div className="space-y-4 mb-6 max-h-60 overflow-y-auto pr-2">
              {cartItems.map((item) => (
                <div key={item.id} className="flex gap-3">
                  <div className="relative flex-shrink-0">
                    <img src={item.image_url} alt={item.name} className="w-16 h-16 object-cover rounded-lg border border-gray-200 bg-white" />
                    <span className="absolute -top-2 -right-2 bg-gray-700 text-white text-xs font-bold w-5 h-5 flex items-center justify-center rounded-full shadow">{item.qty || 1}</span>
                  </div>
                  <div className="flex-1">
                    <h3 className="text-sm font-bold text-gray-800 line-clamp-2">{item.name}</h3>
                    <p className="text-sm text-gray-500 mt-1">€{Number(item.price).toFixed(2)}</p>
                  </div>
                </div>
              ))}
            </div>

            <div className="border-t border-gray-200 pt-4 space-y-2 text-sm">
              <div className="flex justify-between text-gray-600"><span>Subtotal</span><span className="font-semibold text-gray-900">€{subtotal.toFixed(2)}</span></div>
              {promoApplied && promoDiscount > 0 && <div className="flex justify-between text-green-600"><span>Promo Discount</span><span>-€{promoDiscount.toFixed(2)}</span></div>}
              <div className="flex justify-between text-gray-600"><span>Shipping</span><span className={`font-semibold ${finalShippingCost === 0 ? 'text-green-600' : 'text-gray-900'}`}>{finalShippingCost === 0 ? 'FREE' : `€${finalShippingCost.toFixed(2)}`}</span></div>
            </div>

            <div className="border-t border-gray-200 pt-4 mt-4 flex justify-between items-center">
              <span className="text-lg font-extrabold text-gray-900">Total</span>
              <span className="text-2xl font-extrabold text-gray-900">€{finalTotal.toFixed(2)}</span>
            </div>

            {/* TRUST BADGES */}
            <div className="mt-8 pt-6 border-t border-gray-200">
              <div className="flex justify-center gap-4 text-3xl text-gray-500 mb-3">
                <i className="fab fa-cc-visa text-[#1a1f71]"></i>
                <i className="fab fa-cc-mastercard text-[#eb001b]"></i>
                <i className="fab fa-cc-amex text-[#006fcf]"></i>
                <i className="fab fa-cc-paypal text-[#003087]"></i>
                <i className="fab fa-apple-pay text-black"></i>
              </div>
            </div>
          </div>
        </div>

      </div>
    </div>
  );
};

export default ShippingPage;
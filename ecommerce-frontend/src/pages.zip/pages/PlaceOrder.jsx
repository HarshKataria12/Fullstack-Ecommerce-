// src/pages/PlaceOrder.jsx
import { useContext, useEffect, useState } from 'react';
import { useNavigate, Link, useLocation } from 'react-router-dom';
import { CartContext } from '../context/CartContext';

const PlaceOrder = () => {
  const { clearCart, shippingAddress: contextShipping, paymentMethod: contextPayment, cartItems: contextCart } = useContext(CartContext);
  const navigate = useNavigate();
  const location = useLocation();
  const [orderData, setOrderData] = useState(null);
  const [isPlacingOrder, setIsPlacingOrder] = useState(false);
  const [orderComplete, setOrderComplete] = useState(false);
  const [orderNumber, setOrderNumber] = useState('');

  useEffect(() => {
    console.log('PlaceOrder page loaded');
    console.log('Location state:', location.state);
    console.log('Context shipping:', contextShipping);
    console.log('Context payment:', contextPayment);
    console.log('Context cart:', contextCart);
    
    // Priority: location.state > localStorage > context
    let data = null;
    
    if (location.state && location.state.orderData) {
      console.log('Order data received from location state');
      data = location.state.orderData;
    } else {
      // Try to build from context and localStorage
      const shipping = contextShipping && Object.keys(contextShipping).length > 0 ? contextShipping : JSON.parse(localStorage.getItem('shippingAddress') || '{}');
      const payment = contextPayment || JSON.parse(localStorage.getItem('paymentMethod') || 'null');
      const cart = contextCart.length > 0 ? contextCart : JSON.parse(localStorage.getItem('cartItems') || '[]');
      
      if (shipping && Object.keys(shipping).length > 0 && cart.length > 0) {
        const subtotal = cart.reduce((total, item) => total + (Number(item.price) * (item.qty || 1)), 0);
        const shippingCost = shipping.shippingCost || 5.00;
        const promoDiscount = shipping.promoDiscount || 0;
        const finalTotal = subtotal + shippingCost - promoDiscount;
        
        data = {
          subtotal,
          shippingCost,
          promoDiscount,
          finalTotal,
          shippingAddress: shipping,
          paymentMethod: payment,
          cartItems: cart
        };
        console.log('Built order data from context/localStorage');
      }
    }
    
    if (data) {
      setOrderData(data);
    } else {
      console.log('No order data found, redirecting to payment');
      navigate('/payment');
    }
  }, [location, navigate, contextShipping, contextPayment, contextCart]);

  const handlePlaceOrder = async () => {
    setIsPlacingOrder(true);
    
    // Simulate order processing
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    // Generate random order number
    const newOrderNumber = 'ORD-' + Math.random().toString(36).substring(2, 10).toUpperCase();
    setOrderNumber(newOrderNumber);
    
    // Save order to localStorage
    const orderDetails = {
      orderNumber: newOrderNumber,
      items: orderData?.cartItems,
      subtotal: orderData?.subtotal,
      shippingCost: orderData?.shippingCost,
      promoDiscount: orderData?.promoDiscount,
      total: orderData?.finalTotal,
      shippingAddress: orderData?.shippingAddress,
      paymentMethod: orderData?.paymentMethod,
      orderDate: new Date().toISOString()
    };
    
    localStorage.setItem('lastOrder', JSON.stringify(orderDetails));
    
    // Clear cart
    clearCart();
    
    setOrderComplete(true);
    setIsPlacingOrder(false);
    
    // Navigate to confirmation after showing success
    setTimeout(() => {
      navigate('/order-confirmation');
    }, 1500);
  };

  if (!orderData) {
    return (
      <div className="max-w-7xl mx-auto p-4 md:p-8 mt-20">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto"></div>
          <p className="mt-4 text-gray-600">Loading order details...</p>
        </div>
      </div>
    );
  }

  const { subtotal, shippingCost, promoDiscount, finalTotal, shippingAddress, paymentMethod, cartItems } = orderData;
  const taxPrice = Number((0.15 * subtotal).toFixed(2));
  const totalWithTax = finalTotal + taxPrice;

  return (
    <div className="max-w-7xl mx-auto p-4 md:p-8 mt-6">
      
      {/* PROGRESS INDICATOR */}
      <div className="flex justify-center items-center mb-10">
        <div className="flex items-center space-x-2 md:space-x-6">
          <div className="flex flex-col items-center cursor-pointer" onClick={() => navigate('/cart')}>
            <div className="w-8 h-8 rounded-full bg-blue-600 text-white flex items-center justify-center text-sm font-bold">1</div>
            <span className="text-xs mt-1 text-blue-600 font-semibold">Cart</span>
          </div>
          <div className="w-12 md:w-16 h-0.5 bg-blue-600"></div>
          <div className="flex flex-col items-center cursor-pointer" onClick={() => navigate('/shipping')}>
            <div className="w-8 h-8 rounded-full bg-blue-600 text-white flex items-center justify-center text-sm font-bold">2</div>
            <span className="text-xs mt-1 text-blue-600 font-semibold">Checkout</span>
          </div>
          <div className="w-12 md:w-16 h-0.5 bg-blue-600"></div>
          <div className="flex flex-col items-center cursor-pointer" onClick={() => navigate('/payment')}>
            <div className="w-8 h-8 rounded-full bg-blue-600 text-white flex items-center justify-center text-sm font-bold">3</div>
            <span className="text-xs mt-1 text-blue-600 font-semibold">Payment</span>
          </div>
          <div className="w-12 md:w-16 h-0.5 bg-blue-600"></div>
          <div className="flex flex-col items-center">
            <div className="w-8 h-8 rounded-full bg-blue-600 text-white flex items-center justify-center text-sm font-bold">4</div>
            <span className="text-xs mt-1 text-gray-900 font-semibold border-b-2 border-gray-900 pb-1">Place Order</span>
          </div>
        </div>
      </div>

      {!orderComplete ? (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2 space-y-6">
            
            {/* Shipping Review */}
            <div className="bg-white p-6 rounded-xl border border-gray-200 shadow-sm">
              <h2 className="text-xl font-bold mb-4">Shipping Details</h2>
              <p className="text-gray-600">
                <strong>Name:</strong> {shippingAddress?.firstName} {shippingAddress?.lastName}<br />
                <strong>Email:</strong> {shippingAddress?.email}<br />
                <strong>Phone:</strong> {shippingAddress?.phone}<br />
                <strong>Address:</strong> {shippingAddress?.shippingAddressLine}, {shippingAddress?.shippingCity}, {shippingAddress?.shippingPostalCode}, {shippingAddress?.shippingCountry}<br />
                <strong>Shipping Method:</strong> {shippingAddress?.shippingMethod || 'Standard'}
              </p>
            </div>

            {/* Payment Review */}
            <div className="bg-white p-6 rounded-xl border border-gray-200 shadow-sm">
              <h2 className="text-xl font-bold mb-4">Payment Method</h2>
              <p className="text-gray-600">
                <strong>Method:</strong> {paymentMethod?.method} 
                {paymentMethod?.cardLast4 && ` (${paymentMethod?.cardType || 'Card'} ending in ${paymentMethod.cardLast4})`}
              </p>
            </div>

            {/* Items Review */}
            <div className="bg-white p-6 rounded-xl border border-gray-200 shadow-sm">
              <h2 className="text-xl font-bold mb-4">Order Items</h2>
              {cartItems?.map((item, index) => (
                <div key={index} className="flex items-center justify-between py-2 border-b last:border-0">
                  <div className="flex items-center gap-4">
                    <img src={item.image_url} alt={item.name} className="w-12 h-12 object-cover rounded" />
                    <Link to={`/product/${item.id}`} className="text-blue-600 hover:underline font-medium">{item.name}</Link>
                  </div>
                  <div className="text-gray-700">
                    {item.qty || 1} x €{Number(item.price).toFixed(2)} = <span className="font-bold">€{((item.qty || 1) * item.price).toFixed(2)}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Order Summary Sidebar */}
          <div className="lg:col-span-1">
            <div className="bg-gray-50 p-6 rounded-xl border border-gray-200 sticky top-24">
              <h2 className="text-xl font-bold mb-4">Order Summary</h2>
              <div className="space-y-2 text-sm">
                <div className="flex justify-between"><span>Items</span><span>€{subtotal?.toFixed(2)}</span></div>
                <div className="flex justify-between"><span>Shipping</span><span>€{shippingCost?.toFixed(2)}</span></div>
                <div className="flex justify-between"><span>Tax (15%)</span><span>€{taxPrice.toFixed(2)}</span></div>
                {promoDiscount > 0 && (
                  <div className="flex justify-between text-green-600 font-bold">
                    <span>Discount</span><span>-€{promoDiscount.toFixed(2)}</span>
                  </div>
                )}
                <div className="border-t pt-2 flex justify-between text-xl font-extrabold">
                  <span>Total</span><span>€{totalWithTax.toFixed(2)}</span>
                </div>
              </div>
              
              {isPlacingOrder ? (
                <div className="mt-6 text-center">
                  <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mx-auto"></div>
                  <p className="mt-2 text-sm text-gray-600">Processing your order...</p>
                </div>
              ) : (
                <button 
                  onClick={handlePlaceOrder}
                  className="w-full bg-blue-600 text-white py-4 rounded-xl font-bold mt-6 hover:bg-blue-700 transition"
                >
                  Place Order
                </button>
              )}
            </div>
          </div>
        </div>
      ) : (
        <div className="text-center py-12">
          <div className="inline-flex items-center justify-center w-20 h-20 bg-green-100 rounded-full mb-6">
            <svg className="w-10 h-10 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" />
            </svg>
          </div>
          <h2 className="text-2xl font-extrabold text-gray-900 mb-2">Order Placed Successfully!</h2>
          <p className="text-gray-600 mb-4">Your order number is: <strong className="text-blue-600">{orderNumber}</strong></p>
          <p className="text-sm text-gray-500">Redirecting to order confirmation...</p>
          <div className="mt-4 w-full max-w-md mx-auto bg-gray-200 rounded-full h-1.5 overflow-hidden">
            <div className="bg-blue-600 h-1.5 rounded-full animate-pulse w-full"></div>
          </div>
        </div>
      )}
    </div>
  );
};

export default PlaceOrder;
// src/pages/OrderConfirmation.jsx
import { useEffect, useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';

const OrderConfirmation = () => {
  const navigate = useNavigate();
  const [orderDetails, setOrderDetails] = useState(null);

  useEffect(() => {
    const lastOrder = localStorage.getItem('lastOrder');
    if (!lastOrder) {
      navigate('/');
      return;
    }
    setOrderDetails(JSON.parse(lastOrder));
  }, [navigate]);

  if (!orderDetails) {
    return (
      <div className="flex justify-center items-center h-screen">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  const formatDate = (dateString) => {
    if (!dateString) return 'N/A';
    const date = new Date(dateString);
    return date.toLocaleDateString('en-GB', {
      day: 'numeric',
      month: 'long',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  return (
    <div className="max-w-4xl mx-auto p-4 md:p-8 mt-6">
      <div className="text-center mb-8">
        <div className="inline-flex items-center justify-center w-20 h-20 bg-green-100 rounded-full mb-4">
          <svg className="w-10 h-10 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" />
          </svg>
        </div>
        <h1 className="text-3xl font-extrabold text-gray-900 mb-2">Order Confirmed!</h1>
        <p className="text-lg text-gray-600">Thank you for your purchase</p>
        <p className="text-md text-gray-500 mt-2">Order #: <strong className="text-blue-600">{orderDetails.orderNumber}</strong></p>
        <p className="text-sm text-gray-400 mt-1">Placed on: {formatDate(orderDetails.orderDate)}</p>
      </div>

      <div className="bg-white rounded-xl border border-gray-200 p-6 mb-6">
        <h2 className="text-xl font-bold mb-4">Order Summary</h2>
        
        {/* Items List */}
        <div className="space-y-3 mb-4 border-b pb-4">
          {orderDetails.items?.map((item, idx) => (
            <div key={idx} className="flex justify-between items-center">
              <div className="flex items-center gap-3">
                <span className="text-gray-500">{item.qty || 1}x</span>
                <span className="font-medium">{item.name}</span>
              </div>
              <span>€{((item.qty || 1) * Number(item.price)).toFixed(2)}</span>
            </div>
          ))}
        </div>
        
        {/* Price Breakdown */}
        <div className="space-y-2">
          <div className="flex justify-between text-gray-600">
            <span>Subtotal</span>
            <span>€{orderDetails.subtotal?.toFixed(2)}</span>
          </div>
          <div className="flex justify-between text-gray-600">
            <span>Shipping</span>
            <span>{orderDetails.shippingCost === 0 ? 'FREE' : `€${orderDetails.shippingCost?.toFixed(2)}`}</span>
          </div>
          {orderDetails.promoDiscount > 0 && (
            <div className="flex justify-between text-green-600">
              <span>Discount</span>
              <span>-€{orderDetails.promoDiscount?.toFixed(2)}</span>
            </div>
          )}
          <div className="flex justify-between font-bold text-xl pt-2 border-t">
            <span>Total Paid</span>
            <span className="text-blue-600">€{orderDetails.total?.toFixed(2)}</span>
          </div>
        </div>
      </div>

      {/* Shipping Information */}
      {orderDetails.shippingAddress && (
        <div className="bg-white rounded-xl border border-gray-200 p-6 mb-6">
          <h2 className="text-xl font-bold mb-4">Shipping Information</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <p className="text-gray-500 text-sm">Recipient</p>
              <p className="font-medium">{orderDetails.shippingAddress.firstName} {orderDetails.shippingAddress.lastName}</p>
            </div>
            <div>
              <p className="text-gray-500 text-sm">Email</p>
              <p className="font-medium">{orderDetails.shippingAddress.email}</p>
            </div>
            <div className="md:col-span-2">
              <p className="text-gray-500 text-sm">Address</p>
              <p className="font-medium">
                {orderDetails.shippingAddress.shippingAddressLine}
                {orderDetails.shippingAddress.shippingApt && `, ${orderDetails.shippingAddress.shippingApt}`}<br />
                {orderDetails.shippingAddress.shippingCity}, {orderDetails.shippingAddress.shippingState} {orderDetails.shippingAddress.shippingPostalCode}<br />
                {orderDetails.shippingAddress.shippingCountry}
              </p>
            </div>
          </div>
        </div>
      )}

      {/* Payment Information */}
      {orderDetails.paymentMethod && (
        <div className="bg-white rounded-xl border border-gray-200 p-6 mb-6">
          <h2 className="text-xl font-bold mb-4">Payment Information</h2>
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 bg-gray-100 rounded-full flex items-center justify-center">
              <svg className="w-6 h-6 text-gray-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M3 10h18M7 15h1m4 0h1m-7 4h12a3 3 0 003-3V8a3 3 0 00-3-3H6a3 3 0 00-3 3v8a3 3 0 003 3z" />
              </svg>
            </div>
            <div>
              <p className="font-medium">{orderDetails.paymentMethod.method}</p>
              {orderDetails.paymentMethod.cardLast4 && (
                <p className="text-sm text-gray-500">
                  {orderDetails.paymentMethod.cardType} •••• {orderDetails.paymentMethod.cardLast4}
                </p>
              )}
            </div>
          </div>
        </div>
      )}
      
      <Link 
        to="/" 
        className="block mt-6 text-center bg-blue-600 text-white py-3 rounded-xl font-bold hover:bg-blue-700 transition"
      >
        Continue Shopping
      </Link>
    </div>
  );
};

export default OrderConfirmation;
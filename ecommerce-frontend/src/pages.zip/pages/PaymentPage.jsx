// src/pages/PaymentPage.jsx
import { useState, useContext, useEffect } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { CartContext } from '../context/CartContext';

const PaymentPage = () => {
  const { 
    shippingAddress, 
    paymentMethod, 
    savePaymentMethod, 
    cartItems 
  } = useContext(CartContext);
  const navigate = useNavigate();

  // Debug: Log what's available in context
  useEffect(() => {
    console.log('PaymentPage mounted');
    console.log('CartContext available functions:', {
      hasSavePaymentMethod: !!savePaymentMethod,
      savePaymentMethodType: typeof savePaymentMethod,
      hasShippingAddress: !!shippingAddress,
      shippingAddress: shippingAddress,
      hasCartItems: !!cartItems,
      cartItemsCount: cartItems?.length
    });
  }, [savePaymentMethod, shippingAddress, cartItems]);

  // Local state for payment
  const [selectedMethod, setSelectedMethod] = useState(paymentMethod?.method || 'Credit Card');
  const [errors, setErrors] = useState({});
  const [isProcessing, setIsProcessing] = useState(false);
  const [processingStatus, setProcessingStatus] = useState('');
  
  // Credit card form fields
  const [cardNumber, setCardNumber] = useState('');
  const [cardName, setCardName] = useState('');
  const [expiryDate, setExpiryDate] = useState('');
  const [cvv, setCvv] = useState('');
  
  // Security check
  useEffect(() => {
    if (!shippingAddress || !shippingAddress.shippingAddressLine) {
      console.log('No shipping address, redirecting to shipping');
      navigate('/shipping');
    }
  }, [shippingAddress, navigate]);

  // Calculate totals
  const subtotal = cartItems?.reduce((total, item) => total + (Number(item.price) * (item.qty || 1)), 0) || 0;
  const shippingCost = shippingAddress?.shippingCost || 5.00;
  const promoDiscount = shippingAddress?.promoDiscount || 0;
  const finalTotal = subtotal + shippingCost - promoDiscount;

  // Format card number with spaces
  const formatCardNumber = (value) => {
    const v = value.replace(/\s+/g, '').replace(/[^0-9]/gi, '');
    const matches = v.match(/\d{4,16}/g);
    const match = matches && matches[0] || '';
    const parts = [];
    for (let i = 0; i < match.length; i += 4) {
      parts.push(match.substring(i, i + 4));
    }
    if (parts.length) {
      return parts.join(' ');
    } else {
      return value;
    }
  };

  // Format expiry date (MM/YY)
  const formatExpiryDate = (value) => {
    const v = value.replace(/\s+/g, '').replace(/[^0-9]/gi, '');
    if (v.length >= 2) {
      return v.substring(0, 2) + (v.length > 2 ? '/' + v.substring(2, 4) : '');
    }
    return v;
  };

  const handleCardNumberChange = (e) => {
    const formatted = formatCardNumber(e.target.value);
    setCardNumber(formatted);
  };

  const handleExpiryChange = (e) => {
    const formatted = formatExpiryDate(e.target.value);
    setExpiryDate(formatted);
  };

  const validateForm = () => {
    const newErrors = {};
    
    if (!selectedMethod) {
      newErrors.paymentMethod = 'Please select a payment method';
    }
    
    if (selectedMethod === 'Credit Card') {
      const cleanCardNumber = cardNumber.replace(/\s/g, '');
      if (!cleanCardNumber) {
        newErrors.cardNumber = 'Card number is required';
      } else if (cleanCardNumber.length < 16) {
        newErrors.cardNumber = 'Please enter a valid 16-digit card number';
      }
      
      if (!cardName.trim()) {
        newErrors.cardName = 'Name on card is required';
      }
      
      if (!expiryDate) {
        newErrors.expiryDate = 'Expiry date is required';
      } else {
        const [month, year] = expiryDate.split('/');
        if (!month || !year || month.length !== 2 || year.length !== 2) {
          newErrors.expiryDate = 'Please use MM/YY format';
        } else {
          const currentDate = new Date();
          const currentYear = currentDate.getFullYear() % 100;
          const currentMonth = currentDate.getMonth() + 1;
          const expMonth = parseInt(month);
          const expYear = parseInt(year);
          
          if (expYear < currentYear || (expYear === currentYear && expMonth < currentMonth)) {
            newErrors.expiryDate = 'Card has expired';
          }
        }
      }
      
      if (!cvv) {
        newErrors.cvv = 'CVV is required';
      } else if (cvv.length < 3 || cvv.length > 4) {
        newErrors.cvv = 'Please enter a valid 3-4 digit CVV';
      }
    }
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  // Function to save payment data to localStorage directly (fallback)
  const savePaymentToLocalStorage = (paymentData) => {
    try {
      localStorage.setItem('paymentMethod', JSON.stringify(paymentData));
      console.log('Payment data saved directly to localStorage:', paymentData);
      return true;
    } catch (error) {
      console.error('Failed to save to localStorage:', error);
      return false;
    }
  };

  const submitHandler = async (e) => {
    e.preventDefault();
    
    console.log('Submit handler triggered');
    
    if (!validateForm()) {
      console.log('Form validation failed', errors);
      return;
    }
    
    setIsProcessing(true);
    setProcessingStatus('Validating payment details...');
    
    try {
      // Simulate payment processing with steps
      await new Promise(resolve => setTimeout(resolve, 800));
      setProcessingStatus('Processing payment...');
      
      await new Promise(resolve => setTimeout(resolve, 800));
      setProcessingStatus('Saving payment information...');
      
      // Prepare payment data
      const paymentData = {
        method: selectedMethod,
        ...(selectedMethod === 'Credit Card' && {
          cardLast4: cardNumber.slice(-4),
          cardType: getCardType(cardNumber)
        })
      };
      
      console.log('Prepared payment data:', paymentData);
      
      // Try to use the context function if available
      let saveSuccess = false;
      
      if (savePaymentMethod && typeof savePaymentMethod === 'function') {
        try {
          savePaymentMethod(paymentData);
          console.log('Payment data saved via context:', paymentData);
          saveSuccess = true;
        } catch (contextError) {
          console.error('Context save failed:', contextError);
          // Fall back to direct localStorage
          saveSuccess = savePaymentToLocalStorage(paymentData);
        }
      } else {
        console.warn('savePaymentMethod not available, using localStorage fallback');
        saveSuccess = savePaymentToLocalStorage(paymentData);
      }
      
      if (!saveSuccess) {
        throw new Error('Unable to save payment information');
      }
      
      // Prepare order data to pass to PlaceOrder
      const orderData = {
        subtotal,
        shippingCost,
        promoDiscount,
        finalTotal,
        shippingAddress,
        paymentMethod: paymentData,
        cartItems
      };
      
      console.log('Preparing to navigate to PlaceOrder with data:', orderData);
      
      // Small delay to show completion
      await new Promise(resolve => setTimeout(resolve, 500));
      
      setIsProcessing(false);
      
      // Navigate directly to PLACE ORDER page with data
      navigate('/place-order', { 
        state: { orderData },
        replace: false
      });
      console.log('Navigation triggered to /place-order');
      
    } catch (error) {
      console.error('Error in payment processing:', error);
      setIsProcessing(false);
      setProcessingStatus('');
      setErrors({ 
        submit: error.message || 'Failed to save payment information. Please try again.' 
      });
    }
  };

  // Detect card type from number
  const getCardType = (number) => {
    const cleanNumber = number.replace(/\s/g, '');
    if (cleanNumber.startsWith('4')) return 'Visa';
    if (cleanNumber.startsWith('5')) return 'Mastercard';
    if (cleanNumber.startsWith('3')) return 'Amex';
    return 'Card';
  };

  const getDeliveryEstimate = () => {
    if (!shippingAddress?.shippingMethod) return 'Standard delivery';
    const method = shippingAddress.shippingMethod;
    if (method === 'Expedited') return '1-2 business days';
    if (method === 'Economy') return '5-8 business days';
    return '3-5 business days';
  };

  return (
    <div className="max-w-7xl mx-auto p-4 md:p-8 mt-6">
      
      {/* PROGRESS INDICATOR */}
      <div className="flex justify-center items-center mb-10">
        <div className="flex items-center space-x-2 md:space-x-6">
          <div className="flex flex-col items-center cursor-pointer" onClick={() => navigate('/cart')}>
            <div className="w-8 h-8 rounded-full bg-blue-600 text-white flex items-center justify-center text-sm font-bold">1</div>
            <span className="text-xs mt-1 text-blue-600 font-semibold">Cart</span>
          </div>
          <div className="w-12 md:w-16 h-0.5 bg-blue-600"></div>
          <div className="flex flex-col items-center cursor-pointer" onClick={() => navigate('/shipping')}>
            <div className="w-8 h-8 rounded-full bg-blue-600 text-white flex items-center justify-center text-sm font-bold">2</div>
            <span className="text-xs mt-1 text-blue-600 font-semibold">Checkout</span>
          </div>
          <div className="w-12 md:w-16 h-0.5 bg-blue-600"></div>
          <div className="flex flex-col items-center">
            <div className="w-8 h-8 rounded-full bg-blue-600 text-white flex items-center justify-center text-sm font-bold">3</div>
            <span className="text-xs mt-1 text-gray-900 font-semibold border-b-2 border-gray-900 pb-1">Payment</span>
          </div>
          <div className="w-12 md:w-16 h-0.5 bg-gray-300"></div>
          <div className="flex flex-col items-center">
            <div className="w-8 h-8 rounded-full bg-gray-300 text-gray-600 flex items-center justify-center text-sm font-bold">4</div>
            <span className="text-xs mt-1 text-gray-500">Place Order</span>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 lg:gap-10">
        
        {/* LEFT COLUMN: PAYMENT FORM */}
        <div className="lg:col-span-2">
          <div className="flex items-center justify-between mb-6">
            <h1 className="text-2xl md:text-3xl font-extrabold text-gray-900">Payment Method</h1>
            <div className="bg-green-50 text-green-700 text-sm font-semibold px-4 py-2 rounded-full flex items-center gap-2">
              <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 20 20">
                <path fillRule="evenodd" d="M10 9a3 3 0 100-6 3 3 0 000 6zm-7 9a7 7 0 1114 0H3z" clipRule="evenodd" />
              </svg>
              Secure Checkout
            </div>
          </div>
          
          <div className="bg-white rounded-xl border border-gray-200 p-6 md:p-8 shadow-sm">
            <form onSubmit={submitHandler} className="space-y-6">
              
              {/* Payment Method Options */}
              <div className="space-y-4">
                <h2 className="text-lg font-extrabold text-gray-900 mb-2">Select Payment Method</h2>
                
                {/* Credit Card Option */}
                <label className={`flex items-start p-5 border rounded-xl cursor-pointer transition-all ${selectedMethod === 'Credit Card' ? 'border-blue-600 bg-blue-50 shadow-sm' : 'border-gray-200 hover:border-blue-300'}`}>
                  <input 
                    type="radio" 
                    name="paymentMethod" 
                    value="Credit Card" 
                    checked={selectedMethod === 'Credit Card'} 
                    onChange={(e) => setSelectedMethod(e.target.value)} 
                    className="w-5 h-5 text-blue-600 mt-1" 
                  />
                  <div className="ml-4 flex-1">
                    <div className="flex justify-between items-center mb-2">
                      <span className="font-bold text-gray-900 text-lg">Credit Card</span>
                      <div className="flex gap-2 text-2xl">
                        <i className="fab fa-cc-visa text-[#1a1f71]"></i>
                        <i className="fab fa-cc-mastercard text-[#eb001b]"></i>
                        <i className="fab fa-cc-amex text-[#006fcf]"></i>
                      </div>
                    </div>
                    <p className="text-sm text-gray-500">Pay securely with your credit or debit card</p>
                  </div>
                </label>

                {/* Credit Card Form Fields */}
                {selectedMethod === 'Credit Card' && (
                  <div className="ml-9 pl-4 space-y-4 mt-4">
                    <div>
                      <label className="block text-gray-700 font-semibold mb-2">
                        Card Number <span className="text-red-500">*</span>
                      </label>
                      <input 
                        type="text" 
                        value={cardNumber} 
                        onChange={handleCardNumberChange}
                        maxLength="19"
                        className={`w-full p-3 border rounded-xl focus:ring-2 focus:ring-blue-600 outline-none transition ${errors.cardNumber ? 'border-red-500 bg-red-50' : 'border-gray-300'}`}
                        placeholder="1234 5678 9012 3456"
                      />
                      {errors.cardNumber && <p className="text-red-500 text-sm mt-1">{errors.cardNumber}</p>}
                    </div>
                    
                    <div>
                      <label className="block text-gray-700 font-semibold mb-2">
                        Name on Card <span className="text-red-500">*</span>
                      </label>
                      <input 
                        type="text" 
                        value={cardName} 
                        onChange={(e) => setCardName(e.target.value)}
                        className={`w-full p-3 border rounded-xl focus:ring-2 focus:ring-blue-600 outline-none transition ${errors.cardName ? 'border-red-500 bg-red-50' : 'border-gray-300'}`}
                        placeholder="JOHN DOE"
                      />
                      {errors.cardName && <p className="text-red-500 text-sm mt-1">{errors.cardName}</p>}
                    </div>
                    
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <label className="block text-gray-700 font-semibold mb-2">
                          Expiry Date <span className="text-red-500">*</span>
                        </label>
                        <input 
                          type="text" 
                          value={expiryDate} 
                          onChange={handleExpiryChange}
                          maxLength="5"
                          className={`w-full p-3 border rounded-xl focus:ring-2 focus:ring-blue-600 outline-none transition ${errors.expiryDate ? 'border-red-500 bg-red-50' : 'border-gray-300'}`}
                          placeholder="MM/YY"
                        />
                        {errors.expiryDate && <p className="text-red-500 text-sm mt-1">{errors.expiryDate}</p>}
                      </div>
                      <div>
                        <label className="block text-gray-700 font-semibold mb-2">
                          CVV <span className="text-red-500">*</span>
                        </label>
                        <input 
                          type="password" 
                          value={cvv} 
                          onChange={(e) => setCvv(e.target.value.replace(/\D/g, ''))}
                          maxLength="4"
                          className={`w-full p-3 border rounded-xl focus:ring-2 focus:ring-blue-600 outline-none transition ${errors.cvv ? 'border-red-500 bg-red-50' : 'border-gray-300'}`}
                          placeholder="123"
                        />
                        {errors.cvv && <p className="text-red-500 text-sm mt-1">{errors.cvv}</p>}
                      </div>
                    </div>
                    
                    <div className="bg-blue-50 p-3 rounded-lg flex items-center gap-2 text-sm text-blue-800">
                      <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 20 20">
                        <path fillRule="evenodd" d="M5 9V7a5 5 0 0110 0v2a2 2 0 012 2v5a2 2 0 01-2 2H5a2 2 0 01-2-2v-5a2 2 0 012-2zm8-2v2H7V7a3 3 0 016 0z" clipRule="evenodd" />
                      </svg>
                      Test card: 4242 4242 4242 4242 | Exp: <strong className="font-bold">12/27</strong> | CVV: 123
                    </div>
                  </div>
                )}

                {/* PayPal Option */}
                <label className={`flex items-center p-5 border rounded-xl cursor-pointer transition-all ${selectedMethod === 'PayPal' ? 'border-blue-600 bg-blue-50 shadow-sm' : 'border-gray-200 hover:border-blue-300'}`}>
                  <input 
                    type="radio" 
                    name="paymentMethod" 
                    value="PayPal" 
                    checked={selectedMethod === 'PayPal'} 
                    onChange={(e) => setSelectedMethod(e.target.value)} 
                    className="w-5 h-5 text-blue-600" 
                  />
                  <div className="ml-4 flex-1 flex justify-between items-center">
                    <div>
                      <span className="font-bold text-gray-900 text-lg">PayPal</span>
                      <p className="text-sm text-gray-500">Pay quickly with your PayPal account</p>
                    </div>
                    <i className="fab fa-paypal text-[#003087] text-3xl"></i>
                  </div>
                </label>
                
                {errors.paymentMethod && (
                  <p className="text-red-500 text-sm mt-2">{errors.paymentMethod}</p>
                )}
              </div>

              {/* Back to Shipping Link */}
              <div className="mt-4">
                <Link 
                  to="/shipping" 
                  className="text-blue-600 hover:text-blue-700 text-sm font-semibold inline-flex items-center gap-1"
                >
                  <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M15 19l-7-7 7-7" />
                  </svg>
                  Back to shipping
                </Link>
              </div>

              {/* Processing Status */}
              {isProcessing && processingStatus && (
                <div className="bg-blue-50 p-3 rounded-lg text-center">
                  <p className="text-sm text-blue-800 font-medium">{processingStatus}</p>
                </div>
              )}

              {/* Submit Button */}
              <button 
                type="submit" 
                disabled={isProcessing}
                className={`w-full py-4 rounded-xl font-extrabold text-lg transition-all shadow-md hover:shadow-lg flex items-center justify-center gap-2 ${
                  isProcessing 
                    ? 'bg-gray-400 cursor-not-allowed' 
                    : 'bg-blue-600 hover:bg-blue-700 text-white'
                }`}
              >
                {isProcessing ? (
                  <>
                    <svg className="animate-spin h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                      <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                      <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                    </svg>
                    Processing...
                  </>
                ) : (
                  <>
                    Continue to Place Order
                    <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 5l7 7-7 7" />
                    </svg>
                  </>
                )}
              </button>

              {/* Error Message */}
              {errors.submit && (
                <div className="bg-red-50 border border-red-200 p-3 rounded-lg">
                  <p className="text-red-600 text-sm text-center">{errors.submit}</p>
                  <p className="text-xs text-red-500 text-center mt-1">
                    Please check your card details and try again.
                  </p>
                </div>
              )}
            </form>
          </div>
        </div>

        {/* RIGHT COLUMN: ORDER SUMMARY */}
        <div className="lg:col-span-1">
          <div className="bg-gray-50 rounded-xl border border-gray-200 sticky top-24">
            <div className="p-6">
              <h2 className="text-xl font-extrabold text-gray-900 mb-4 flex items-center gap-2">
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M16 11V7a4 4 0 00-8 0v4M5 9h14l1 12H4L5 9z" />
                </svg>
                Order Summary
              </h2>
              
              {/* Cart Items */}
              <div className="space-y-4 mb-6 max-h-60 overflow-y-auto pr-2 custom-scroll">
                {cartItems?.map((item) => (
                  <div key={item.id} className="flex gap-3">
                    <div className="relative flex-shrink-0">
                      <img 
                        src={item.image_url} 
                        alt={item.name} 
                        className="w-16 h-16 object-cover rounded-lg border border-gray-200 bg-white"
                        onError={(e) => e.target.src = 'https://via.placeholder.com/64?text=Product'}
                      />
                      <span className="absolute -top-2 -right-2 bg-gray-700 text-white text-xs font-bold w-5 h-5 flex items-center justify-center rounded-full shadow">
                        {item.qty || 1}
                      </span>
                    </div>
                    <div className="flex-1 min-w-0">
                      <h3 className="text-sm font-bold text-gray-800 line-clamp-2">{item.name}</h3>
                      <p className="text-sm text-gray-500 mt-1">€{Number(item.price).toFixed(2)}</p>
                    </div>
                  </div>
                ))}
              </div>

              {/* Price Breakdown */}
              <div className="border-t border-gray-200 pt-4 space-y-2 text-sm">
                <div className="flex justify-between">
                  <span className="text-gray-600">Subtotal</span>
                  <span className="font-semibold text-gray-900">€{subtotal.toFixed(2)}</span>
                </div>
                {promoDiscount > 0 && (
                  <div className="flex justify-between text-green-600">
                    <span>Promo Discount</span>
                    <span>-€{promoDiscount.toFixed(2)}</span>
                  </div>
                )}
                <div className="flex justify-between">
                  <span className="text-gray-600">Shipping</span>
                  <span className={`font-semibold ${shippingCost === 0 ? 'text-green-600' : 'text-gray-900'}`}>
                    {shippingCost === 0 ? 'FREE' : `€${shippingCost.toFixed(2)}`}
                  </span>
                </div>
                <div className="flex justify-between text-gray-500 italic">
                  <span>Estimated Tax</span>
                  <span>Calculated at next step</span>
                </div>
              </div>

              {/* Final Total */}
              <div className="border-t border-gray-200 pt-4 mt-2 flex justify-between items-center">
                <span className="text-lg font-extrabold text-gray-900">Total</span>
                <span className="text-2xl font-extrabold text-gray-900">€{finalTotal.toFixed(2)}</span>
              </div>

              {/* Delivery Estimate */}
              <div className="mt-4 pt-4 border-t border-gray-200">
                <div className="flex items-center gap-2 text-sm text-gray-600">
                  <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
                  </svg>
                  <span>Delivery to: <strong>{shippingAddress?.shippingAddressLine}, {shippingAddress?.shippingCity}</strong></span>
                </div>
                <div className="flex items-center gap-2 text-sm text-gray-600 mt-2">
                  <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                  </svg>
                  <span>Estimated delivery: <strong>{getDeliveryEstimate()}</strong></span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <style jsx>{`
        .custom-scroll::-webkit-scrollbar {
          width: 4px;
        }
        .custom-scroll::-webkit-scrollbar-track {
          background: #e5e7eb;
          border-radius: 10px;
        }
        .custom-scroll::-webkit-scrollbar-thumb {
          background: #9ca3af;
          border-radius: 10px;
        }
      `}</style>
    </div>
  );
};

export default PaymentPage;